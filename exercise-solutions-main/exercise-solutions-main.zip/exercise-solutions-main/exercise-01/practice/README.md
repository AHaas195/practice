# READ ME

Files used for exercises will normally be stored here for reference. (In Week 1, there are no files.)
