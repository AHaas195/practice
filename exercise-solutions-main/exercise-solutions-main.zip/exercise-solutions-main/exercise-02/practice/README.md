# README

To download this repository, click the green **Code** button. Select **Open with GitHub Desktop.**

## Contents

- README.md (this file)
- wdw.txt


## Credit

wdw.txt includes content from Wikipedia (CC BY-SA).
