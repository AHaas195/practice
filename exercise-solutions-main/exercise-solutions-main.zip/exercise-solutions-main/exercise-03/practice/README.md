# README

To download this repository, click the green **Code** button. Select **Open with GitHub Desktop.**

## Contents

- README.md (this file)
- ibis-news.html
- macintosh-128k.html
- more-html-practice.html

## Credit

macintosh-128k.html includes content from Wikipedia (CC BY-SA).
