# README

This directory contains three possible solutions for `ibis-news.html`.

`ibis-news-01.html` contains the most simple solution; `ibis-news-02.html` and `ibis-news-03.html` are variations determined through more critical examination of the content.
