# README

This directory contains the fully coded exercises, taking both text tags and structural tags into account.
